package br.com.alura.mvc.mudi.api;

import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.alura.mvc.mudi.dto.RequisicaoNovaOferta;
import br.com.alura.mvc.mudi.model.Oferta;
import br.com.alura.mvc.mudi.model.Pedido;
import br.com.alura.mvc.mudi.repository.PedidoRepository;

@RestController
@RequestMapping("/api/ofertas")
public class OfertasRest {
	
	@Autowired
	private PedidoRepository pedidoRepository;
	
	@PostMapping //pega os dados da requisição e seta na classe RequisicaoNovaOferta
	public Oferta novaOferta(@Valid @RequestBody RequisicaoNovaOferta requisicao) {
		Optional<Pedido> pedidoLocalizado = pedidoRepository.findById(requisicao.getPedidoId());
		Pedido pedido;
		
		if(!pedidoLocalizado.isPresent()) {
			return null;
		}else {
			pedido = pedidoLocalizado.get(); //atribui o pedido localizado no BD na classe pedido
		}
		
		Oferta oferta = requisicao.toOferta(); //passa os atributos da requisição para classe oferta
		oferta.setPedido(pedido);
		pedido.getOfertas().add(oferta); 
		
		pedidoRepository.save(pedido); //Lazy, salva a oferta tbm
		
		return oferta;
	}

}
