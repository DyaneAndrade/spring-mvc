package br.com.alura.mvc.mudi.controller;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.alura.mvc.mudi.model.Oferta;
import br.com.alura.mvc.mudi.model.Pedido;
import br.com.alura.mvc.mudi.model.StatusPedido;
import br.com.alura.mvc.mudi.repository.OfertaRepository;
import br.com.alura.mvc.mudi.repository.PedidoRepository;

@Controller
@RequestMapping("/ofertas")
public class OfertaController {

	@Autowired
	private OfertaRepository ofertaRepository;
	
	@Autowired
	private PedidoRepository pedidoRepository;

	@GetMapping("/home")
	public String getHomeDeOfertas() {

		return "oferta/home";
	}

	@GetMapping("/pedido/{id}")
	public String exibiOferta(Model model, @PathVariable("id")Long id, @RequestParam("nome") String nome, @RequestParam("idPedido")Long idPedido) {

		List<Oferta> ofertas = ofertaRepository.findAllOfertaByPedido(id);

		System.out.println(ofertas.toString());

		model.addAttribute("ofertas", ofertas);
		model.addAttribute("nome", nome);
		model.addAttribute("idPedido", idPedido);
		
		System.out.println(idPedido);

		return "pedido/oferta";
	}

	@GetMapping("/confirmada/{idPedido}")
	public String ofertaConfirmada(Model model, @PathVariable("idPedido")Long idPedido, @RequestParam("valor")BigDecimal valor,
			@RequestParam("data")String data) {
		
		LocalDate dataFormatter = LocalDate.parse(data);
		
		Optional<Pedido> findById = pedidoRepository.findById(idPedido);
		Pedido pedido = findById.get();
		
		
		pedido.setId(idPedido);
		pedido.setValorNegociado(valor);
		pedido.setDataEntrega(dataFormatter);
		pedido.setStatus(StatusPedido.APROVADO);
		
		pedidoRepository.save(pedido);
		
		System.out.println("Salvou");
		
		return "redirect:usuario/home";
	}

}
