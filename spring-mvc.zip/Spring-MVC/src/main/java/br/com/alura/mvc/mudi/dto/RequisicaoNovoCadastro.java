package br.com.alura.mvc.mudi.dto;

import javax.validation.constraints.NotBlank;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import br.com.alura.mvc.mudi.model.Usuario;

//É uma classe que serve apenas transferir objetos.
public class RequisicaoNovoCadastro {

	@NotBlank
	private String username;
	@NotBlank
	private String password;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Usuario toUser() {
		Usuario user = new Usuario();
		
		user.setUsername(username);
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		user.setPassword(encoder.encode(password));

		user.setEnabled(true);

		return user;
	}

}
