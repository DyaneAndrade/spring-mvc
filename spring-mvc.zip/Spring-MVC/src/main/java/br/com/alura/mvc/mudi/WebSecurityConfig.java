package br.com.alura.mvc.mudi;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import br.com.alura.mvc.mudi.repository.UserRepository;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private DataSource dataSource;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
		.authorizeRequests()
		.antMatchers("/home/**").permitAll()
		.antMatchers("/cadastro/**").permitAll()
		.anyRequest().authenticated()
		.and()
				.formLogin(form -> form.loginPage("/login").permitAll().defaultSuccessUrl("/usuario/pedidos", true))
				.logout(logout -> logout.logoutUrl("/logout").logoutSuccessUrl("/home"));
				
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		
//		UserDetails user =
//				User.builder()
//				.username("Livia.Andrade")
//				.password(encoder.encode("123456"))
//				.roles("ADM")
//				.build();
		
		
		auth.jdbcAuthentication()
			.dataSource(dataSource)
			.passwordEncoder(encoder); //criptografa as senhas
//			.withUser(user); 
	}

//	@Bean
//	@Override
//	public UserDetailsService userDetailsService() {
//		UserDetails user =
//				User.withDefaultPasswordEncoder()
//				.username("Dyane.Andrade")
//				.password("1234")
//				.roles("ADM")
//				.build();
//		
//		return new InMemoryUserDetailsManager(user);
//		
//	}

}
